"""Build three full-length editions with the structural manuscript's original typography."""
from pathlib import Path
import re, shutil, sys, argparse, hashlib,json
BASE=Path(__file__).resolve().parent
def read(d,p):
    return (d/p).read_text()
def span(text,a,b):
    i=text.index(a);return text[i:text.index(b,i)]
def replace(text,a,b):
    assert text.count(a)==1,a
    return text.replace(a,b)
S2=r'\section{The metric, its representation'
S3=r'\section{Local boundary tools}'
S6=r'\section{From admissible domains'
S4=r'\section{Singular vectors and the amplified estimate}'
DOM=r'\begin{theorem}[The bound on an analytic convex domain]'
def adapted_test(s):
    t=span(s,DOM,r'\section{Enclosing domains')
    t=replace(t,span(t,'Choose $h$','Put $\\gamma'),r'''Choose $h$ as in Lemma~\ref{lem:conformal-coordinates}. The estimates we shall use are Lemma~\ref{prop:coefficients} and Proposition~\ref{lem:resolvent}. The vectors $x,y$ below are singular vectors for this particular $F$, at arbitrary coefficient size $m$. They are independent of the endpoint vectors in Proposition~\ref{prop:extremal}.
''')
    t=t.replace('Theorem~\\ref{lem:resolvent}','Proposition~\\ref{lem:resolvent}').replace('Proposition~\\ref{prop:coefficients}','Lemma~\\ref{prop:coefficients}')
    t=t.replace(r'b_k(A)',r'R_k').replace(r'Since $b_0=1$',r'Since $R_0=I$')
    t=replace(t,r'For a polynomial $G=\sum_k b_kC_k$, direct expansion in the tensor basis gives',r'For any test polynomial $G$, insert the expansion $G[A]=\sum_k R_k\otimes C_k$ from Proposition~\ref{lem:resolvent}. Direct expansion in the tensor basis gives')
    t=replace(t,span(t,'Write the full finite Faber expansions', 'The functional in'),r'''Let $U_k$ and $V_k$ be the nonnegative Fourier coefficients of the full boundary products $(FG)\circ h$ and $(GF)\circ h$. Both arrays are finite by Lemma~\ref{prop:coefficients}. These are the coefficients of the actual products, including all interactions between their positive and negative modes. Put
\[
 \|H\|_\partial^2=\int_\T\HS{H(h(\mu))}^2\,d\tau(\mu).
\]
''')
    t=t.replace('to these full expansions','to these full coefficient arrays')
    t=replace(t,'For the first inequality, set',r'''The triangular recovery in Lemma~\ref{prop:coefficients} guarantees the existence of the polynomial with each of the arrays we now prescribe. For the first inequality, set''')
    t=t.replace(r'\HS{',r'\HSize{').replace(r'd\tau',r'd\sigma')
    assert 'b_k' not in t and 'Faber' not in t
    return t
def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('structural',type=Path); a.add_argument('direct',type=Path)
    a.add_argument('license',type=Path);a.add_argument('output',type=Path)
    args=a.parse_args()
    orig,other=(read(d,'main.tex') for d in [args.structural,args.direct])
    if hashlib.sha256(orig.encode()).hexdigest()!='8a5de532bd3bd4c0b84cc8114c22175968813a6e984ced0d1bf48011270e621c':raise ValueError('structural source mismatch')
    if hashlib.sha256(other.encode()).hexdigest()!='54a429fe7129b4760b3015fabf2269d4de5fa38aba9539b18542c1df7e58333f':raise ValueError('direct source mismatch')
    p=BASE/'material'
    doc=orig.replace(r'\author{OpenAI}',r'\author{Original manuscript by OpenAI. Comparison edition by ChatGPT.}').replace(r'\date{September 23, 2026}',r'\date{Source September 23, 2026. Revision November 21, 2026.}').replace('pdfauthor={OpenAI}', 'pdfauthor={OpenAI (source); ChatGPT (comparison edition)}')
    doc=doc.replace(r'\begin{document}',r'''\newcommand{\HSize}[1]{\lvert #1\rvert_2}
\usepackage{embedfile}
\begin{document}
\embedfile[desc={Upstream source license},mimetype=text/plain]{LICENSE}''')
    test=adapted_test(other)
    tex_mid='\n\n'.join([read(p,'trace.tex'),read(p,'resolvent.tex'),test,read(p,'endpoint.tex')])
    for mode in ['original','trace-gaussian','trace-polygon']:
        t=doc
        if mode!='original':
            t=replace(t,span(t,'The direct proof in',r'\subsection*{How the two'),r'''The September 23 manuscript constructs the optimal metric and a common positive representation. The September 26 companion \cite{Direct} uses two singular-vector tests for the polynomial inequality. This edition retains the first manuscript's metric construction and final results. Sections~\ref{sec:inputs}--\ref{sec:bridge} prove the needed polynomial estimate in ordinary Fourier coordinates, with the ordered tests adapted from the companion. Section~\ref{sec:comparison} then applies that estimate to the extremal for the chosen metric.

''')
            t=replace(t,span(t,'Once the extremal vectors are available',S2),read(p,'roadmap.tex')+'\n')
            t=replace(t,span(t,S3,S6),tex_mid+'\n\n')
            if mode=='trace-polygon':
                t=replace(t,span(t,'The Gaussian-distance construction below','We then transfer'),r'''The support-exponential construction below supplies the required domains, including when the numerical range is a point or a segment. It implements the polygon approach in the compact revision; a direction-net version appears in \cite[Section 4]{Direct}. ''')
                t=t.replace('Gaussian analytic outer approximation','Analytic outer approximation by supporting lines')
                i=t.index(r'\begin{proof}',t.index(r'\label{lem:gaussian}'))
                j=t.index(r'\end{proof}',i)+len(r'\end{proof}')
                t=t[:i]+read(p,'polygon.tex').rstrip()+t[j:]
        head={'original':'Original structural proof','trace-polygon':'Restored steps: polygon','trace-gaussian':'Restored steps: Gaussian'}[mode]
        t=t.replace(r'\fancyhead[R]{\small Structural route}',r'\fancyhead[R]{\small '+head+'}')
        dest=args.output/mode
        dest.mkdir(exist_ok=True,parents=True)
        shutil.copytree(args.structural/'figures',dest/'figures',dirs_exist_ok=True)
        shutil.copy2(args.structural/'references.tex',dest/'references.tex')
        shutil.copy2(args.license,dest/'LICENSE')
        (dest/'main.tex').write_text(t)
if __name__=='__main__':
    main()
