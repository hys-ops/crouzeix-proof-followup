# The complete Crouzeix theorem — a restored proof comparison

Read the [three-page review note](review/note.pdf). The question is whether the September 26 analytic-domain estimate can bound the metric already constructed in §2 of the September 23 manuscript. The note shows the approximation and similarity argument and identifies the original proof steps this replaces.

| Read in this order | What is included |
|---|---|
| [21 pages, Gaussian edition](editions/trace-gaussian/main.pdf) | Recommended comparison. Read Proposition 2.2 (p. 6), Theorem 4.2 (pp. 10–12) and §5 (pp. 12–13). This edition keeps the entirety of the original §6. |
| [22 pages, matched structural baseline](editions/original/main.pdf) | Compare Proposition 3.3, §4 (especially (4.6) and (4.10)) and Lemma 5.1. This PDF uses the original proof and a common comparison-edition title treatment. The official upstream PDF is linked below. |
| [21 pages, polygon/exponential edition](editions/trace-polygon/main.pdf) | The earlier restored edition, with the same §§3–5 and an alternative proof of analytic outer approximation in §6. |
| [Measurements](checks/measured.json) | Full pagination, independently reflowed proof sections, continuous TeX heights, full-source SHA-256 hashes, and the results of text-identity checks. |

Both restored manuscripts provide the detailed proof of the domain estimate. A reader who accepts direct Theorem 3.2 can instead read just the conditional argument on p. 1 of the review note. The full comparison counts all of that domain proof. The whole work goes from 22 to 21 pages. The 13-page count in the measurements is the independently typeset §§2–6 extract.

## Reproduce

The inputs are local. Use Python 3, pdfLaTeX with a full TeX Live distribution (including Latin Modern, TikZ, microtype, needspace, embedfile and hyperref), and Poppler's pdfinfo. Run from the unpacked directory containing this README:

~~~sh
python3 reproduce.py rebuilt
~~~

Use an empty or new output directory. The script authenticates the six source files against the pinned upstream Git blob IDs, regenerates each edition, compares its TeX with the included edition, compiles each complete document three times, then measures both separately typeset proof ranges with the original preamble. It compares the result with the retained JSON. A difference in TeX or fonts may change line breaks and heights. PDF dates and metadata may change even if all measurements match. The published measurements use pdfTeX and the versions in [the replay record](checks/replay.txt). To check the distributed files before running the build on Linux, use `sha256sum --quiet -c SHA256SUMS`.

The original 11-point type, 1.05-inch margins and line spacing are common to the three measured PDFs. The two subsection ranges overlap; do not add their page counts or heights. Each full PDF contains its main proof, appendix and references. The review note is an independent guide.

## Sources, credit and verification

OpenAI is the author of both source manuscripts. The six TeX inputs and their paths are listed in [the source record](checks/upstream.json) under commit `4eaee87548250b2682affda7d05d947c05554bae`. The upstream material, including passages reused in the comparison editions, carries the accompanying [Apache License 2.0](LICENSE). The byline on the archived comparison PDFs credits OpenAI for the original and ChatGPT for the comparison. Public contributor identity for the proposed note is reserved.

- [September 23 structural manuscript, including official PDF](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/preprints/The-complete-Crouzeix-theorem-September-23-2026)
- [September 26 direct companion, including official PDF](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/preprints/A-direct-proof-of-the-complete-Crouzeix-inequality-September-26-2026)
- [September 23 community page](https://mathcommunity.github.io/oai-math-revised/papers/The-complete-Crouzeix-theorem-September-23-2026/) · [Xie §9.4.6](https://arxiv.org/html/2610.17090v1) · [Latent Seminar](https://lowrank.github.io/latent-seminar/OpenAI-Math/325-complete-crouzeix) · [Independent check of the upstream Lean development](https://github.com/Beltran12138/oai-math-recheck)

The text-identity checks include Theorems 1.2–1.3, Propositions 2.1–2.2, Corollaries 6.1 and 6.3, the entire metric construction in §2, the sharpness witness, and the conformal appendix. The Gaussian edition also keeps §6 verbatim. The polygon edition keeps everything from the proof of Corollary 6.1 onward. The scripts check source and typesetting; mathematical validity of the replacement depends on the written proof. AI prepared the manuscripts and tooling and compared the arguments. The restored editions have not been formally verified end to end in Lean, and no independent human mathematical sign-off is recorded.

The source of the review note is [note.tex](review/note.tex). To typeset it independently, run `pdflatex -halt-on-error note.tex` twice from `review/`.
