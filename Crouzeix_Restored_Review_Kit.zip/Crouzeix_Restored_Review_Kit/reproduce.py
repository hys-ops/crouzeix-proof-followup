"""From a fresh directory, rebuild and measure the three complete manuscripts."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

KIT = Path(__file__).resolve().parent
EDITIONS = ("original", "trace-gaussian", "trace-polygon")

def source_check():
    lock = json.loads((KIT / "checks/upstream.json").read_text())
    for name, item in lock["files"].items():
        data = (KIT / name).read_bytes()
        digest = hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
        if digest != item["git_blob"] or len(data) != item["size"]:
            raise ValueError(f"Mismatch against the pinned upstream blob for {name}")

def run(*args, cwd=KIT, log=None):
    subprocess.run(args, cwd=cwd, check=True, stdout=log, stderr=subprocess.STDOUT)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="fresh output directory")
    output = parser.parse_args().directory.resolve()
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        parser.error("please use a new or empty output directory")
    output.mkdir(parents=True, exist_ok=True)
    source_check()
    run(sys.executable, "make.py", "upstream/structural", "upstream/direct", "LICENSE", output)
    with (output / "build.txt").open("w") as log:
        for edition in EDITIONS:
            folder = output / edition
            if (folder/"main.tex").read_bytes() != (KIT/"editions"/edition/"main.tex").read_bytes():
                raise ValueError(f"Generated TeX differs in {edition}")
            for _ in range(3):
                run("pdflatex","-halt-on-error","-interaction=batchmode","main.tex",cwd=folder,log=log)
            citations = (folder / "main.log").read_text(errors="replace")
            if re.search(r"undefined citations|Citation .+ undefined",citations):
                raise ValueError(f"Unresolved citations in {edition}")
    run(sys.executable, "audit.py", output, KIT/"upstream/structural/main.tex", output/"results.json")
    if json.loads((output/"results.json").read_text()) != json.loads((KIT/"checks/measured.json").read_text()):
        raise SystemExit("A measured value differs. Compare the two results.json files and check TeX/font versions.")
    print("Six upstream Git blobs, three complete TeX editions, six statements, retained proof sections and all measurements match.")

if __name__ == "__main__":
    main()
