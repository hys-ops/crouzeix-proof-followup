"""Measure paginated and uninterrupted proof blocks with the manuscript's own preamble."""
import argparse, collections,hashlib,json,re,shutil,subprocess,tempfile
from pathlib import Path

def call(*args, cwd=None):
    return subprocess.check_output(list(args),cwd=cwd,stderr=subprocess.STDOUT)
def pages(path):
    return int(re.search(r'Pages:\s+(\d+)',call('pdfinfo',str(path)).decode())[1])
def pdftex(name,d):
    try:call('pdflatex','-halt-on-error','-interaction=batchmode',name+'.tex',cwd=d)
    except subprocess.SubprocessError:
        raise RuntimeError((d/(name+'.log')).read_text(errors='replace')[-2300:])
    log=(d/(name+'.log')).read_text(errors='replace')
    assert not re.search(r'undefined on input line|undefined references|multiply defined|Overfull \\hbox',log)
    return log
def segment(tex,a,b):
    i=tex.index(a);return tex[i:tex.index(b,i)]
def measure(src,body,counter):
    text=(src/'main.tex').read_text()
    pre=text[:text.index(r'\begin{document}')]
    start=pre+r'\begin{document}\pagestyle{empty}\setcounter{section}{'+str(counter)+'}\n'
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp);shutil.copy2(src/'main.aux',d/'core.aux')
        (d/'core.tex').write_text(start+body+'\n'+r'\end{document}')
        pdftex('core',d)
        num=pages(d/'core.pdf')
        shutil.copy2(src/'main.aux',d/'ruler.aux')
        unbroken=r'\setbox0=\vbox{\hsize=\textwidth\def\Needspace#1{}'+'\n'+body+'\n'+r'\par}\typeout{COREHT=\the\dimexpr\ht0+\dp0\relax}\end{document}'
        (d/'ruler.tex').write_text(start+unbroken)
        log=pdftex('ruler',d)
        return {'reflowed_pages':num,'height_tex_pt':float(re.search(r'COREHT=([\d.]+)pt',log)[1])}
def sha(t):return hashlib.sha256(t.encode()).hexdigest()
def statement(ref,s,env):
    i=s.index(r'\label{'+ref+'}');beg=s.rindex(r'\begin{'+env+'}',0,i)
    end=s.index(r'\end{'+env+'}',i)+len(r'\end{'+env+'}')
    return s[beg:end]
def stamp(s,anchor):
    env=r'\begin{'+anchor+'}';i=s.index(env);end=r'\end{'+anchor+'}'
    return s[i:s.index(end,i)+len(end)]
S2=r'\section{The metric, its representation'
S3a=r'\section{Local boundary tools}'
S3b=r'\section{Exterior coordinates and boundary traces}'
S6=r'\section{From admissible domains'
APP=r'\appendix'
SHARP=r'For sharpness take $n=2$'
RESULTS=[('thm:structural','theorem'),('thm:representation','theorem'),('prop:density','proposition'),('prop:extremal','proposition'),('cor:polynomial','corollary'),('cor:hilbert','corollary')]
def inspect(root,kind,orig):
    d=root/kind; t=(d/'main.tex').read_text(); old=(kind=='original');s3=S3a if old else S3b
    log=(d/'main.log').read_text(errors='replace')
    assert not re.search(r'undefined on input line|undefined references|multiply defined|Overfull \\hbox',log)
    cls=re.compile(r'^\\(?:documentclass|setlength|usepackage|fancyhead|fancyfoot|pagestyle).+',re.M)
    layouts=[x for x in cls.findall(t) if not x.startswith(r'\fancyhead[R]') and 'embedfile' not in x]
    assert layouts==[x for x in cls.findall(orig) if not x.startswith(r'\fancyhead[R]') and 'embedfile' not in x]
    keep={'section2_byte_identical':segment(t,S2,s3)==segment(orig,S2,S3a),
          'section6_byte_identical':segment(t,S6,APP)==segment(orig,S6,APP),
          'sharpness_proof_byte_identical':segment(t,SHARP,r'\end{proof}')==segment(orig,SHARP,r'\end{proof}'),
          'appendix_and_bibliography_call_byte_identical':t[t.index(APP):]==orig[orig.index(APP):],
          'six_statements_byte_identical':{k:statement(k,t,e)==statement(k,orig,e) for k,e in RESULTS}}
    for label,val in keep.items():
        if label=='section6_byte_identical' and kind=='trace-polygon':assert not val
        elif label=='six_statements_byte_identical':assert all(val.values())
        else:assert val
    if kind=='trace-polygon':
        a=r'\begin{proof}[Proof of Corollary~\ref{cor:polynomial}]'
        keep['from_proof_of_cor6_1_through_end_byte_identical']=t[t.index(a):]==orig[orig.index(a):]
        assert keep['from_proof_of_cor6_1_through_end_byte_identical']
    return {'full_pages':pages(d/'main.pdf'),
            'core_2_to_6':measure(d,segment(t,S2,APP),1),
            'changed_route_3_to_5':measure(d,segment(t,s3,S6),2),
            'kept':keep,'source_sha256':sha(t)}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('build',type=Path);p.add_argument('original_source',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    out={k:inspect(a.build.resolve(),k,a.original_source.read_text()) for k in ['original','trace-gaussian','trace-polygon']}
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    for k,v in out.items():print(k,v['full_pages'],v['core_2_to_6'],v['changed_route_3_to_5'])
